// JavaScript para mostrar/ocultar el menú hamburguesa en dispositivos móviles
const menuToggle = document.getElementById("menu-toggle");
const nav = document.querySelector("nav");

menuToggle.addEventListener("click", function () {
    nav.classList.toggle("active");
});
function validarInicioSesion() {
    const usuario = document.getElementById('usuario').value;
    const contraseña = document.getElementById('contraseña').value;
  
    if (usuario === 'usuario123' && contraseña === 'contraseña123') {
      alert("Inicio Exitoso");
      mostrarContenido('contenido-inicio');
    } else {
      alert('Usuario o contraseña incorrectos');
    }
  }
  function calcularPrestamo() {
    // Obtener los valores ingresados por el usuario
    var principal = parseFloat(document.getElementById("loanAmount").value);
    var tasaInteresAnual = parseFloat(document.getElementById("interestRate").value) / 100;
    var plazoMeses = parseFloat(document.getElementById("loanTerm").value);
    
    // Calcular el monto del préstamo
    var montoPrestamo = principal;
    
    // Calcular el pago mensual
    var interesMensual = tasaInteresAnual / 12;
    var pagoMensual = principal * (interesMensual * Math.pow(1 + interesMensual, plazoMeses)) / (Math.pow(1 + interesMensual, plazoMeses) - 1);
    var pagoTotal = principal * (interesMensual * Math.pow(1 + interesMensual, plazoMeses)) / (Math.pow(1 + interesMensual, plazoMeses) - 1) + principal;
    
    // Mostrar los resultados en la página
    document.getElementById("montoPrestamo").innerHTML = montoPrestamo.toFixed(2);
    document.getElementById("pagoMensual").innerHTML = pagoMensual.toFixed(2);
    document.getElementById("pagoTotal").innerHTML = pagoTotal.toFixed(2);
  }
  function convertirMoneda() {
    const cantidad = parseFloat(document.getElementById('amount').value);
    const fromCurrency = document.getElementById('fromCurrency').value;
    const toCurrency = document.getElementById('toCurrency').value;

    const conversionRates = {
      usd: 1,
      eur: 1.10, // Valor de referencia, ajustar según los valores reales
      ars: 0.00135, // Valor de referencia, ajustar según los valores reales
    };

    const resultado = cantidad * conversionRates[fromCurrency] / conversionRates[toCurrency];
    document.getElementById('resultado').textContent = `${cantidad} ${fromCurrency} equivale a ${resultado.toFixed(2)} ${toCurrency}`;
}
  function realizarPago() {
    const factura = document.getElementById('factura').value;
    const montoPago = parseFloat(document.getElementById('monto-pago').value);
  
    // Tu lógica para realizar el pago aquí
    alert(`Se ha realizado un pago de $${montoPago} para la factura ${factura}`);
  }
  function realizarTransferencia() {
    const monto = parseFloat(document.getElementById('monto').value);
    const destino = document.getElementById('destino').value;
  
    // Tu lógica para realizar la transferencia aquí
    alert(`Se ha transferido $${monto} a la cuenta ${destino}`);
  }
  // Mostrar contenido de inicio al cargar la página
  window.onload = function() {
    mostrarContenido('contenido-inicio');
  };